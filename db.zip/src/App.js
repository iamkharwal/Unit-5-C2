/** @format */

import { Forms } from "./components/Forms";

function App() {
  return (
    <div>
      <Forms />
    </div>
  );
}

export default App;
